#ifndef __EXTI_H
#define __EXIT_H	 
#include "sys.h"	 
void EXTI_Init(void);	//�ⲿ�жϳ�ʼ��		 					    
#endif

























