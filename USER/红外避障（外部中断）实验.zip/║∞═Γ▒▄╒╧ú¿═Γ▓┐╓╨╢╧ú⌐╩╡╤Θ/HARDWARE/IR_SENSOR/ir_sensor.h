#ifndef IR_SENSOR_H
#define IR_SENSOR_H
void ir_sensor_init(void);
#endif