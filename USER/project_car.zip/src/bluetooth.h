#ifndef __BLUETOOTH_H
#define __BLUETOOTH_H

void usart_init();
void usart2_send_byte(char data);
// char usart1_recv_byte(void);

#endif
